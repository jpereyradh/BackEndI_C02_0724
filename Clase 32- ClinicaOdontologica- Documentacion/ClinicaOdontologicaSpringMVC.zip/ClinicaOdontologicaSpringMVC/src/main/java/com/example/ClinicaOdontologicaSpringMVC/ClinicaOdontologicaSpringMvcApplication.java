package com.example.ClinicaOdontologicaSpringMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaOdontologicaSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaOdontologicaSpringMvcApplication.class, args);
	}

}
