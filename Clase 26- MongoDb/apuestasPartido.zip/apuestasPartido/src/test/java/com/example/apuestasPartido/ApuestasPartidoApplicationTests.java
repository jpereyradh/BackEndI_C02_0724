package com.example.apuestasPartido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApuestasPartidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
